var swiper = new Swiper(".mySwiper", {
    effect: "cards",
    grabCursor: true,
  })