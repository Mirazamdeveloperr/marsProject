// let login = "mirazam"
// let password ="123"

// let ism = prompt("login")


// if(login === ism) {
//     console.log("tog'ri keldi")
//     let parol = prompt("Parol")

//     if(password === parol){
//         console.log("parol togri")
//     }
//     else{
//         console.log("parol notogri ")
//     }
// } else{
//     console.log("tog'ri kelmadi")
// }



let Capucin = "15000"

let Amerikano = "10000"

let Ice = "20000"

let menu = prompt(" 1) Capucino: 15000sum \n 2) Amerikano: 10000sum \n 3) Ice coffee: 20000sum ")

if (menu === "1") {
    console.log("===========================")
    console.log()
}