    // let var const
// const =constanta ozgartirib bo'lmidgan qiymat
// let = o'zgartirib boladigan 

let ism = prompt("ISM YOZ:")
let familiya = prompt("Familiya: ")
let yosh = prompt("yosh:")
let oqish = prompt("oqish:")
let rangi = prompt("rang:")
let son = prompt("son:")


console.log("============================================")
console.log("Ismi: " + ism)
console.log("familiya: " + familiya)
console.log("yosh: " + yosh) 
console.log("oqish: " + oqish)
console.log("rang: " +rangi)
console.log("son: " + son)
console.log("============================================")



