// let savol1 = prompt("Uzb poytaxti: \n A) Toshkent B) Horazim C) Trmiz")

// switch (savol1) {
//     case "A" :
//         console.log("Togri")
//     break
    
//     case "B" :
//         console.log("Notogri")
//     break
    
//     case "C" : 
//         console.log("Notogri")
//     break    
// }

// let savol2 = prompt("2*2 = : \n A) 34, B) 42, C) 4.")

// switch (savol2) {
//     case "A" :
//         console.log("Notogri")
//     break

//     case "B" : 
//         console.log("Notogri")
//     break

//     case "C" :
//         console.log("Togri")
// }

// let savol3 = prompt("5*5= : \n A) 23, B) 13, C) 10.")

// switch (savol3) {
//     case "A" :
//         console.log("Notogri")
//     break
    
//     case "B" : 
//         console.log("Togri")
//     break
    
//     case "C" : 
//         console.log("Notogri")
//     break
// }

// let savol4 = prompt("Uzbda nechta viloyat bor: \n A) 12, B) 45, C) 14.")

// switch (savol4) {
//     case "A" :
//         console.log("Togri")
//     break
    
//     case "B" : 
//         console.log("Notogri")
//     break
    
//     case "C" : 
//         console.log("Notogri")
//     break
// }

// let savol5 = prompt("Hoz  qatdasa : \n A) yashnaobod, B) Yunusobod, C) yakkasaroy.")

// switch (savol5) {
//     case "A" :
//         console.log("Notogri")
//     break
    
//     case "B" : 
//         console.log("Togri")
//     break
    
//     case "C" : 
//         console.log("Notogri")
//     break
// } 

// let array = [
//     "Uzb poytaxti: \n A) Toshkent B) Samarqand C) Jizzax",
//     "2*2 = : \n A) 5 B) 3 C) 4",
//     "5*5= : \n A) 10 B) 25 C) 10",
//     "Uzbda nechta viloyat bor: \n A) 12 B) 25 C) 10",
//     "Hoz  qatdasa : \n A) yashnaobod B) Yunusobod C) yakkasaroy"

// ]

for  (let i = 0; i < array.length; i++) {
    console.log(array[i])

    switch (array[i]) {
        case "A" :
            console.log("Togri")
        default: 
            console.log("Notogri")  
    }
}



        
        


