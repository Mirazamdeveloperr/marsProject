// function num (ism){
//     let random = Math.floor(Math.random() * 10) + 1

//     if (random < 5){
//         console.log(` ${ism} Xunuk` )

//     } else 
//     {
//         console.log(` ${ism} chiroyli`)
//     }
// }

// num("Mirazam")

let registr = []

function registratsiya(login, password) {
    login = prompt("login yoz so'tiqo'zi:")
    registr.push(login)

    password = prompt()
}