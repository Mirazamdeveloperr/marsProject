
let DataBase = [ 
    { 
        carName: "BMW", 
        color: "red", 
        engine: "V12", 
        price: "120.000$" 
    }, 
    { 
        carName: "BYD", 
        color: "White", 
        engine: "240kwt", 
        price: "60.000$" 
    }, 
    { 
        carName: "Mersades-Benz", 
        color: "black", 
        engine: "V12", 
        price: "200.000$" 
    }, 
    { 
        carName: "Cobalt", 
        color: "Gan", 
        engine: "V20", 
        price: "500.000$" 
    }, 
]

let body = bocument.querySelector("body")

DataBase.map(item => {
    crossOriginIsolated.log()
    
})
